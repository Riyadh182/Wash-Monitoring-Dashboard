# Wash & Dry Hourly Monitoring (Streamlit + Google Sheets)

Pilot unit: **CWL-1** (53 wash machines, 15 dry processes). Floor staff type numbers into a Google Sheet; this app reads the sheet and shows
plan vs actual, input, WIP, quality, rewash, downtime, machine-wise and process-wise views, style search, trends and data health.

```
Google Sheet (entry)  ->  Streamlit app (GitHub -> Streamlit Community Cloud)  ->  browser / phone
   Wash_Log, Dry_Log, WIP_Log, masters        reads every 60 s (cached), read-only
```

## Folder
| Path | What |
|---|---|
| `app.py` | Dashboard UI (7 tabs) |
| `calc.py` | All calculations (plain pandas, unit-tested) |
| `data.py` | Loads Google Sheets (live) or `demo_data/` (demo) |
| `demo_data/` | 21 days of sample CWL-1 data so the app runs before the Sheet is connected |
| `apps_script/Code.gs` | Adds "Wash Tools > Create rows for a day" to the Google Sheet |
| `tools/` | `make_template.py` (sheet template per unit), `make_demo_data.py`, `units_config.json` (from Capacity_August_2026) |
| `tests/` | `test_calc.py` (logic), `smoke_app.py` (runs app with stubs) |

## 1. Google Sheet
1. Upload `Wash_Pilot_Template_CWL-1.xlsx` to Google Drive -> open with Google Sheets -> *File > Save as Google Sheets*.
2. *Extensions > Apps Script* -> paste `apps_script/Code.gs` -> Save -> reload the sheet.
3. Every production day: **Wash Tools > Create rows for a day** (pre-fills Date, Hour, Unit, Machine/Process for 24 hours).
4. Floor enters numbers only. Filter the Hour column to work hour by hour.
5. Set real values in `Settings` (run hours, day start, limits) and edit `Plan_per_hr` per machine in `Master_Machine`.

Other units: `cd tools && python3 make_template.py CWL-2 ../Wash_Pilot_Template_CWL-2.xlsx`.
Dry-process capacity for BWL-1, BWL-2, EWDL and SZWDL in Capacity_August_2026 is identical to CWL-1..4 (looks copy-pasted); NWL has none. Verify before using those units.

## 2. Google service account (read-only access for the app)
1. Google Cloud Console -> new project -> enable **Google Sheets API** and **Google Drive API**.
2. IAM -> Service Accounts -> create -> Keys -> *Add key > JSON* (downloads a file; keep it private).
3. Share your Google Sheet with the service account's `client_email` as **Viewer**.

## 3. GitHub
1. Create a **private** repository, upload this whole folder (or `git push`). `.gitignore` already blocks secrets and JSON keys.
2. Never commit the service-account JSON or `secrets.toml`.

## 4. Streamlit Community Cloud
1. share.streamlit.io -> sign in with GitHub -> **Create app** -> pick the repo, branch `main`, main file `app.py`.
2. *Advanced settings > Secrets*: paste the content of `.streamlit/secrets.toml.example` filled with your JSON key values and the Sheet ID(s).
3. Deploy. Then in the app's *Share* settings restrict viewers to invited email addresses (otherwise anyone with the link can open it).
4. Without secrets the app shows **DEMO data** (red DEMO chip) - useful to test the layout first.

## 5. Month end and the yearly record
- Streamlit Cloud has no permanent disk, so the history lives in Google Sheets.
- Month end: *File > Make a copy* of the Sheet (e.g. `WASH_CWL-1_2026-10`) -> add its ID to `archive = [...]` in Secrets -> clear the data rows (not headers) of Wash_Log / Dry_Log / WIP_Log in the live Sheet.
- Trends and Style Explorer then read current + archive Sheets together (whole year). Masters/Settings are read from the current Sheet only.
- Keep one Sheet per unit per month. Full machine-hour logging is ~1,272 wash rows/day for CWL-1 (~38k/month), well inside Google's 10M-cell limit.

## Notes
- Plan = `Plan_per_hr` (per machine, from capacity / machines / run hours) x Plan_Basis x hours. Dry plan = process capacity per day / run hours.
- Dry "process-pcs": one garment can pass several processes, so dry totals sum across processes. Read dry performance per process.
- Style plan does not exist, so with a style or wash-type filter on, plan/achievement/WIP are hidden and only actuals are filtered.
- Date is the **production date**; with Day_Start_Hour = 8, hours after midnight belong to the same production date.
- Apps sleep after inactivity on the free Streamlit plan; the first visit may take a moment to wake it.

## Run locally
```
pip install -r requirements.txt
streamlit run app.py          # demo data; add .streamlit/secrets.toml for live data
python tests/test_calc.py      # calculation tests
```
